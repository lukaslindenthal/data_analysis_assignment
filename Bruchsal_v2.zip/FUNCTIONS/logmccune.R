## Log transformation of matrices with values between 0 and 1 according to McCune & Grace
## Usage: logmccune (x, outfile, dig=10)
## dig is optional for unifying scales among different matrices, standard is 10 (0.0000000001)
## Example: 
## logmccune (values, "logvalues.txt")

logmccune <- function (x, dig=10) {
  ## Round if necessary
  x <- round(x, digits = dig)
  
  ## Transform and write table
  constant.c <- round(log10(min(replace(x, x == 0, 1))))
  constant.d <- 10 ^ constant.c
  log.x <- log10(x + constant.d) - constant.c  
  log.x
}


