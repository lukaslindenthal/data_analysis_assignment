# PCQM functions
# Requires a list with matrices, each with 4 rows and columns for species name, distance and DBH in cm (at 130 cm)

#x1 <- data.frame(Species = c("Acacia", "Eucalyptus", "Casuarina", "Callitris"), Distance = c(1.1, 1.6, 2.3, 3.0), DBH = c(6, 48, 15, 11))
#x2 <- data.frame(Species = c("Eucalyptus", "Casuarina", "Acacia", "Casuarina"), Distance = c(2.8, 3.7, 0.9, 2.2), DBH = c(65, 16, 8, 9))
#x3 <- data.frame(Species = c("Acacia", "Acacia", "Acacia", "Acacia"), Distance = c(2.8, 1.1, 3.2, 1.4), DBH = c(4, 6, 6, 5))
#x4 <- data.frame(Species = c("Callitris", "Casuarina", "Casuarina", "Callitris"), Distance = c(1.3, 0.8, 0.7, 3.1), DBH = c(19, 22, 12, 7))
#x5 <- data.frame(Species = c("Acacia", "Acacia", "Eucalyptus", "Eucalyptus"), Distance = c(1.5, 2.4, 3.3, 1.7), DBH = c(7, 5, 27, 36))

#dat <- list(x1, x2, x3, x4, x5)

pcqm <- function(dat) {
  result <- list()
  # Nearest Point-to-tree-distances
  # The sum of the nearest point-to-tree distances in the quarters surveyed divided by the number of quarters
  r <- sum(unlist(lapply(dat, function(i) sum(i$Distance)))) / (length(dat) * 4)
  result[["Mean_distance"]] <- r

  # Absolute density
  d <- 1 / (r^2)
  result[["Absolute_density"]] <- d

  # Absolute density of each species
  species <- mapply('[', dat, TRUE, 1)
  dk <- as.matrix(table(species) / (length(dat) * 4) * d * 10000)
  dkn <- as.numeric(dk)
  names(dkn) <- rownames(dk)
   result[["Absolute_densities_of_species"]] <- dkn

  # Relative density of a species
  rd <- dk / 10000 / d * 100
  rdn <- as.numeric(rd)
  names(rdn) <- rownames(rd)
  result[["Relative_densities_of_species"]] <- rdn

  # Basal area of each tree
  dbh <- mapply('[', dat, TRUE, 3)
  # c2/4π
  ba <- as.numeric(dbh) ^ 2 / 4 * pi
  mba <- aggregate(ba, by = list(as.factor(species)), FUN = mean)
  mban <- as.numeric(mba[, 2])
  names(mban) <- mba[, 1]  
  result[["Mean_basal_area_of_species"]] <- mban

  # Basal_area_per_ha
  tba <- mba[, 2] * dk / 10000
  colnames(tba) <- "Basal_area_per_ha"
  tban <- as.numeric(tba)
  names(tban) <- rownames(tba)
  result[["Basal_area_per_ha_and_species"]] <- tban

  # Basal_area_per_ha
  sba <- sum(tba)
  result[["Total_basal_area_per_ha"]] <- sba

  # Relative Cover (Relative Dominance) of a Species
  rc <- tban / sba * 100
  result[["Relative_cover_by_species"]] <- rc

  # Absolute Cover of a Species
  io <- nocc <- table(species, rep(1:length(dat), each = 4))
  io[io > 0] <- 1
  # Number of sample points with a species
  nsp <- rowSums(io)
  result[["Number_of_sample_points_with_species"]] <- nsp

  # Frequency of species
  fps <- nsp / length(dat) * 100
  result[["Frequency_by_species"]] <- fps

  # Relative frequency of species
  rfps <- fps / sum(fps) * 100
  result[["Relative_frequency_per_species"]] <- rfps

  # Theimportance valueof a species is defined as the sum of the three relative measures
  # Relative density+Relative cover+Relative frequency
  ai <- rdn + rc + rfps
  ri <- ai / sum(ai) * 100
  result[["Relative_importance_of_species"]] <- ri
  
  result
}  

#pcqm(dat)

