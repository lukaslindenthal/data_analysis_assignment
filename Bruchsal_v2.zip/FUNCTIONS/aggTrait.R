# Calculate mean species trait values for plot records

# x                     Matrix with species abundance (up to 100%) in plots (species are columns)
#                       Use % and not values scaled to one.
# trait                 Vector with species trait values, same length as ncol(x)
# grouping              Optional grouping vector if there are multiple measurements per plot for taxa
#
# Values
# means                 Vector of average trait values. If a grouping of species names is
#                       provided, each group counts once per plot
# medians               Vector of median trait values. Grouping is considered as for means
# cover_weighted_means  Vector of cover weighted means. If a grouping of species names
#                       is provided, a total cover value is calculated based on the formula
#                       published by H. Fischer (2015) Appl. Veget. Science 18: 169–170

aggTrait <- function(x, trait, grouping = NULL) {
  
  if (length(trait) != ncol(x)) stop('length of trait vector needs to match ncol(x)')
  
  hagenFischer <- function(x) 1 - prod(1 - x)
  
  x1 <- x  
  
  # Replace species cover values by trait values
  x1[x1 <= 0] <- NA # No occurrence is NA, not 0
  for (i in 1:ncol(x1)) x1[, i][!is.na(x1[, i])] <- trait[i]
  
  # Means
  means   <- rowMeans(x1, na.rm = TRUE)
  # Medians
  medians <- apply(x1, 1, median, na.rm=TRUE)  
  # Weighted means
  wmeans <- rep(NA, nrow(x))
  names(wmeans) <- names(means)
  for (j in 1:nrow(x1)) wmeans[j] <- weighted.mean(x1[j, ], w = x[j, ], na.rm = TRUE)

  # Accounting for multiple occurrences per plot
  if (length(grouping) > 0) {
    x2 <- t(x1)
    grp <- list(as.factor(grouping))
    x3 <- aggregate(x2, grp, min)[, -1]
    cat("Taking account of", nrow(x3), "groups\n")
   
    # Means
    means <- colMeans(x3, na.rm = TRUE)
    # Medians
    medians <- apply(x3, 2, median, na.rm = TRUE) 
    # Weighted means
    # First aggregate cover values to total cover, using the formula published by Hagen Fischer
    x4 <- t(x / 100)
    x5 <- aggregate(x4, grp, hagenFischer)[, -1]
    wmeans <- rep(NA, ncol(x3))
    names(wmeans) <- names(means)
    for (k in 1:ncol(x3)) wmeans[k] <- weighted.mean(x3[, k], w = x5[, k], na.rm = TRUE)
  }  
    
  list(means = means, cover_weighted_means = wmeans, medians = medians)
}  
