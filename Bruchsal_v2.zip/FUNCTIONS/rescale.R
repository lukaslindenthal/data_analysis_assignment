rescale <- function(x) {
  a <- x - min(x, na.rm = TRUE)
  b <- a / max(a, na.rm = TRUE)
  3 * b * 0.8 + 0.2  
}  